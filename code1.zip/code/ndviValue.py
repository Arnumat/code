import cv2
import numpy as np
from fastiecm import fastiecm
import statistics as st

def findLeafArea(image):
    #image = cv2.imread(image)
    blank_mask = np.zeros(image.shape, dtype=np.uint8)
    original = image.copy()
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    # set lower and upper color limits
    lower_val = (0, 18, 0)
    upper_val = (60, 255, 120)
    # Threshold the HSV image to get only green colors
    mask = cv2.inRange(hsv, lower_val, upper_val)
    # Perform morphological operations
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    opening = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
    close = cv2.morphologyEx(opening, cv2.MORPH_CLOSE, kernel, iterations=1)
    # Find contours and filter for largest contour
    # Draw largest contour onto a blank mask then bitwise-and
    cnts = cv2.findContours(close, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[0] if len(cnts) == 2 else cnts[1]
    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)[0]
    cv2.fillPoly(blank_mask, [cnts], (255, 255, 255))
    blank_mask = cv2.cvtColor(blank_mask, cv2.COLOR_BGR2GRAY)
    cv2.imshow("frame",blank_mask)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    # cv2.imshow("show :",blank_mask)
    # cv2.waitKey(1000)
    number_of_white_pix = np.sum(blank_mask == 255)
    convertToCm = 0.0264583333 * number_of_white_pix
    print('result :', convertToCm,'cm^2 ')
    return convertToCm



def display(image, image_name):
    image = np.array(image, dtype=float)/float(255)
    shape = image.shape
    height = int(shape[0] / 2)
    width = int(shape[1] / 2)
    image = cv2.resize(image, (width, height))
    return image



#set contrast
def contrast_stretch(im):
    in_min = np.percentile(im, 5)
    in_max = np.percentile(im, 95)

    out_min = 0.0
    out_max = 255.0

    out = im - in_min
    out *= ((out_min - out_max) / (in_min - in_max))
    out += in_min
    return out

def calc_ndvi(image):
    b, g, r = cv2.split(image)
    bottom = (r.astype(float) + b.astype(float))
    bottom[bottom==0] = 0.01
    ndvi = (r.astype(float) - b) / bottom # THIS IS THE CHANGED LINE
    
    print('min :'+str(ndvi.min()))
    print('max :'+str(ndvi.max()))
    print('mean :'+str(ndvi.mean()))
    return ndvi




def contouring(image,color_map):
    # Read image, create blank masks, color threshold

    blank_mask = np.zeros(image.shape, dtype=np.uint8)
    original = image.copy()
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    mask = cv2.inRange(hsv, (0, 18, 0), (60, 255, 120))

    # Perform morphological operations
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    opening = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
    close = cv2.morphologyEx(opening, cv2.MORPH_CLOSE, kernel, iterations=1)

    # Find contours and filter for largest contour
    # Draw largest contour onto a blank mask then bitwise-and
    cnts = cv2.findContours(close, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[0] if len(cnts) == 2 else cnts[1]
    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)[0]
    cv2.fillPoly(blank_mask, [cnts], (255, 255, 255))
    blank_mask = cv2.cvtColor(blank_mask, cv2.COLOR_BGR2GRAY)
    #blank_mask = cv2.bitwise_not(blank_mask)
    
 
    result = cv2.bitwise_and(original,original, mask=blank_mask)
    # Crop ROI from result
    x, y, w, h = cv2.boundingRect(blank_mask)
    ROI = result[y:y+h, x:x+w]

    # image in this case is your image you want to eliminate black
    result[np.where((result == [0, 0, 0]).all(axis=2))] = [255, 255, 255]
    
    return result



original =cv2.VideoCapture("http://192.168.42.36:1234/video")

park = display(original, 'Original')

contrasted =park
ndvi = calc_ndvi(contrasted)
ndvi_contrasted =contrast_stretch(ndvi)
color_mapped_prep = ndvi_contrasted.astype(np.uint8)
color_mapped_image = cv2.applyColorMap(color_mapped_prep, fastiecm)

contouring(original,color_mapped_image)

while True :
    findLeafArea(original)
    



