from picamera import PiCamera


cam = PiCamera()
cam.resolution = (1920,1080)
cam.vflip = True

cam.start_preview()
tim.sleep(2)

cam.capture("noir.jpg")